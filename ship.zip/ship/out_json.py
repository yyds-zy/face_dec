#!/usr/bin/env python3
"""
batch_detect_and_write_json.py

批量对文件夹内图片做 OBB 检测并输出标准化 JSON。
依赖：ultralytics, opencv-python, numpy, rasterio

用法示例:
python tools/detection/train/carry_0312/out_json.py \
    --img-dir /home/bit/zhyjFiles/SceneDesign_1224/tools/detection/train/carry_0312/data_folder \
    --out-json /home/bit/zhyjFiles/SceneDesign_1224/tools/detection/train/carry_0312/detections.json \
    --model /home/bit/zhyjFiles/SceneDesign_1224/tools/detection/train/carry_0312/best.pt
"""

import argparse
import json
import uuid
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import cv2
import rasterio
from rasterio.transform import from_bounds

import os
import sys


custom_path = os.path.abspath("./tools/detection")
if custom_path not in sys.path:
    sys.path.insert(0, custom_path)


from ultralytics import YOLO

# --------------------------
# 你提供的 DetectionYOLO 类，略作封装以便批量调用
# --------------------------
class DetectionYOLO:
    def __init__(self, model_path='weights/yolov8s-obb.pt'):
        self.model = YOLO(model_path)

    def detect_on_image(self, img_np, conf=0.5):
        """
        输入：BGR numpy 图像（OpenCV 风格）
        输出：results 对象（ultralytics 的结果序列）
        """
        results = self.model(
            source=img_np,
            task="obb",
            conf=conf,
            verbose=False
        )
        return results

# --------------------------
# 辅助：读取 JSON 中的四角和时间（尝试若干常见键）
# 返回 (corners_list, timestamp_str)
# corners_list: list of 4 [lon, lat] 例如 [ [lon,lat], [lon,lat], ... ]
# --------------------------
def load_image_metadata(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        j = json.load(f)

    # 尝试常见键
    possible_corner_keys = ['corners', 'corner_coords', 'image_corners', 'geo_corners', 'four_corners', 'bbox_corners']
    corners = None
    for k in possible_corner_keys:
        if k in j and isinstance(j[k], (list, tuple)) and len(j[k]) == 4:
            corners = j[k]
            break

    # 如果没找到，递归查找第一个长度4且元素为数对的列表
    if corners is None:
        def find_4_pairs(obj):
            if isinstance(obj, (list, tuple)):
                if len(obj) == 4 and all(isinstance(p, (list, tuple)) and len(p) == 2 for p in obj):
                    return obj
                for e in obj:
                    found = find_4_pairs(e)
                    if found:
                        return found
            elif isinstance(obj, dict):
                for v in obj.values():
                    found = find_4_pairs(v)
                    if found:
                        return found
            return None
        corners = find_4_pairs(j)

    # 标准化 corners 为 list of [lon, lat]（尝试放宽顺序）
    if corners is None:
        raise ValueError(f"No 4-corners found in {json_path}")
    # make sure each pair is float
    corners = [[float(coord[0]), float(coord[1])] for coord in corners]

    # try timestamp keys
    time_keys = ['timestamp', 'time', 'datetime', 'obtain_time', 'capture_time']
    timestamp = None
    for tk in time_keys:
        if tk in j:
            timestamp = str(j[tk])
            break

    # fallback: try to find any ISO-like string value
    if timestamp is None:
        def find_time(obj):
            if isinstance(obj, str):
                # rudimentary ISO check
                if 'T' in obj and ':' in obj:
                    return obj
            if isinstance(obj, dict):
                for v in obj.values():
                    t = find_time(v)
                    if t:
                        return t
            if isinstance(obj, (list,tuple)):
                for v in obj:
                    t = find_time(v)
                    if t:
                        return t
            return None
        timestamp = find_time(j)

    if timestamp is None:
        # fallback to file mtime with UTC timezone
        timestamp = datetime.fromtimestamp(
            Path(json_path).stat().st_mtime,
            tz=timezone.utc
        ).isoformat(timespec='seconds')

    return corners, timestamp, j


def normalize_iso8601(ts_raw):
    """
    统一为 ISO 8601: yyyy-MM-ddTHH:mm:ss±HH:mm
    """
    if ts_raw is None:
        dt = datetime.now(timezone.utc)
        return dt.isoformat(timespec='seconds')

    ts = str(ts_raw).strip()
    if not ts:
        dt = datetime.now(timezone.utc)
        return dt.isoformat(timespec='seconds')

    if ts.endswith('Z'):
        ts = ts[:-1] + '+00:00'

    try:
        dt = datetime.fromisoformat(ts)
    except ValueError:
        # 兼容常见无时区格式
        parse_patterns = [
            '%Y-%m-%d %H:%M:%S',
            '%Y/%m/%d %H:%M:%S',
            '%Y-%m-%dT%H:%M:%S',
        ]
        dt = None
        for pat in parse_patterns:
            try:
                dt = datetime.strptime(ts, pat)
                break
            except ValueError:
                continue
        if dt is None:
            dt = datetime.now(timezone.utc)

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    return dt.isoformat(timespec='seconds')


def normalize_lon_lat(lon, lat):
    """
    经纬度转十进制度并做范围校验。
    """
    lon_f = float(lon)
    lat_f = float(lat)
    if not (-180.0 <= lon_f <= 180.0):
        raise ValueError(f'Longitude out of range: {lon_f}')
    if not (-90.0 <= lat_f <= 90.0):
        raise ValueError(f'Latitude out of range: {lat_f}')
    return lon_f, lat_f


def get_optional_metadata(meta_json, img_path):
    """
    预留子函数：从源数据补齐可选信息。
    不存在则返回 None，后续可按业务扩展。
    """
    return {
        'image_url': meta_json.get('image_url'),
        'sensor_type': meta_json.get('sensor_type'),
        'scene_type': meta_json.get('scene_type'),
        'algorithm_version': meta_json.get('algorithm_version'),
        'processing_status': meta_json.get('processing_status', 'success'),
        'subtype_map': meta_json.get('subtype_map', {}),
        'attributes_map': meta_json.get('attributes_map', {}),
        'request_id': meta_json.get('request_id'),
        'image_id': meta_json.get('image_id', img_path.name),
    }


def build_request_id(capture_time_iso, optional_meta):
    if optional_meta.get('request_id'):
        return str(optional_meta['request_id'])
    dt_part = datetime.fromisoformat(capture_time_iso).strftime('%Y%m%d')
    rand_part = uuid.uuid4().hex[:6].upper()
    return f'REQ_{dt_part}_{rand_part}'

# --------------------------
# 将像素点 (x, y) -> 地理坐标 (lon, lat)
# 两种策略：
#   1) 如果四角近似轴对齐，使用 rasterio.transform.from_bounds + rasterio.transform.xy （优先）
#   2) 否则使用 cv2.getPerspectiveTransform + cv2.perspectiveTransform（回退）
# corners_geo: list of 4 [lon, lat] in order assumed correspond to pixel corners [(0,0),(w,0),(w,h),(0,h)]
# --------------------------
def build_pixel_to_geo_transform(corners_geo, img_width, img_height, tol_deg=1e-6):
    """
    返回一个 dict:
      { 'mode': 'rasterio', 'transform': affine_transform } 或
      { 'mode': 'perspective', 'matrix': 3x3 numpy float32 matrix }
    """
    # Ensure corners shape
    if len(corners_geo) != 4:
        raise ValueError("corners_geo must be length 4")

    # We assume corners order corresponds to pixel corners:
    # pixel corners: tl=(0,0), tr=(w,0), br=(w,h), bl=(0,h)
    # geo corners: [ [lon,lat], ... ] same order or not? We'll try to detect order.
    # We'll attempt to detect if the quad is axis-aligned: top lat ~ same, left lon ~ same
    # We'll compute min/max
    lons = [c[0] for c in corners_geo]
    lats = [c[1] for c in corners_geo]
    lon_min, lon_max = min(lons), max(lons)
    lat_min, lat_max = min(lats), max(lats)

    # Check if roughly axis-aligned rectangle: corners should be nearly combinations of (lon_min/lon_max, lat_min/lat_max)
    approx_coords = set([
        (lon_min, lat_min),
        (lon_min, lat_max),
        (lon_max, lat_min),
        (lon_max, lat_max),
    ])
    given_coords = set((round(c[0],6), round(c[1],6)) for c in corners_geo)
    approx_coords_rounded = set((round(a,6), round(b,6)) for (a,b) in approx_coords)
    axis_aligned = given_coords == approx_coords_rounded

    if axis_aligned:
        # Use rasterio.from_bounds: left, bottom, right, top
        left = lon_min
        right = lon_max
        bottom = lat_min
        top = lat_max
        transform = from_bounds(left, bottom, right, top, img_width, img_height)
        return {'mode': 'rasterio', 'transform': transform}
    else:
        # Fallback: build perspective matrix mapping pixel coords -> geo (lon,lat)
        # pixel_pts: [[0,0],[w,0],[w,h],[0,h]]
        src = np.array([[0.0, 0.0],
                        [img_width, 0.0],
                        [img_width, img_height],
                        [0.0, img_height]], dtype=np.float32)
        dst = np.array(corners_geo, dtype=np.float32)  # expecting shape (4,2) as [lon,lat]
        M = cv2.getPerspectiveTransform(src, dst)  # 3x3
        return {'mode': 'perspective', 'matrix': M}

def pixel_to_geo(transform_info, x, y):
    """
    输入 x,y (pixel coord: x is col, y is row), 返回 (lon, lat)
    """
    if transform_info['mode'] == 'rasterio':
        transform = transform_info['transform']
        # rasterio.transform.xy expects row (y), col (x)
        # note: by default offset='center' returns center of pixel; we pass offset=0.5 to be explicit
        lon, lat = rasterio.transform.xy(transform, y, x, offset='center')
        return float(lon), float(lat)
    else:
        M = transform_info['matrix']
        pt = np.array([[[float(x), float(y)]]], dtype=np.float32)  # shape (1,1,2)
        dst = cv2.perspectiveTransform(pt, M)  # gives [[[lon, lat]]]
        lon, lat = float(dst[0,0,0]), float(dst[0,0,1])
        return lon, lat

# --------------------------
# 主流程：遍历图片、检测、写 CSV
# --------------------------
def process_folder(img_dir, out_json_path, model_path, conf=0.5, supported_exts=None):
    if supported_exts is None:
        supported_exts = ['.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff']

    detector = DetectionYOLO(model_path=model_path)

    img_dir = Path(img_dir)
    if not img_dir.exists():
        raise FileNotFoundError(img_dir)

    out_json_path = Path(out_json_path)
    out_json_path.parent.mkdir(parents=True, exist_ok=True)

    # collect all images
    imgs = [p for p in img_dir.iterdir() if p.suffix.lower() in supported_exts]
    imgs = sorted(imgs)
    print(f'Found {len(imgs)} images in {img_dir}')

    all_records = []

    for img_path in imgs:
        try:
            print(f'Processing {img_path.name} ...')
            # load image
            img = cv2.imread(str(img_path))
            if img is None:
                print(f'[WARN] cv2.imread failed for {img_path}, skip')
                continue
            h, w = img.shape[:2]

            # read corresponding json
            json_path = img_path.with_suffix('.json')
            if not json_path.exists():
                print(f'[WARN] json not found for {img_path.name} (expected {json_path}), skip')
                continue

            corners_geo, timestamp_str, meta_json = load_image_metadata(str(json_path))
            capture_time_iso = normalize_iso8601(timestamp_str)
            optional_meta = get_optional_metadata(meta_json, img_path)
            request_id = build_request_id(capture_time_iso, optional_meta)

            # build transform
            try:
                transform_info = build_pixel_to_geo_transform(corners_geo, w, h)
            except Exception as e:
                print(f'[WARN] build transform failed for {img_path.name}: {e}, skip')
                continue

            # compute image center lat/lon
            center_x = w / 2.0
            center_y = h / 2.0
            img_center_lon, img_center_lat = pixel_to_geo(transform_info, center_x, center_y)
            try:
                img_center_lon, img_center_lat = normalize_lon_lat(img_center_lon, img_center_lat)
            except ValueError as e:
                print(f'[WARN] image center lon/lat invalid for {img_path.name}: {e}, skip')
                continue

            # run detection (use BGR numpy)
            results = detector.detect_on_image(img, conf=conf)
            img_draw = img.copy()

            detected_objects = []
            obj_counter = 0

            for res in results:
                # for OBB, user used res.obb
                obb = getattr(res, 'obb', None)
                if obb is None:
                    continue
                # try to get polys (N,8)
                try:
                    polys = obb.xyxyxyxy.cpu().numpy()  # N x 8
                    confs = obb.conf.cpu().numpy()
                    clss = obb.cls.cpu().numpy()
                except Exception:
                    # alternative attribute names depending on ultralytics version
                    try:
                        polys = obb.xyxyxyxy.numpy()
                        confs = obb.conf.numpy()
                        clss = obb.cls.numpy()
                    except Exception:
                        print("[WARN] couldn't read obb fields, skip this result")
                        continue

                # result.names: mapping id->name
                names_map = getattr(res, 'names', None)
                for i in range(len(polys)):
                    poly = polys[i].reshape(4,2)  # 4x2 (x,y) pixel coordinates (float)
                    conf_val = float(confs[i])
                    cls_idx = int(clss[i])
                    if isinstance(names_map, dict):
                        cls_name = names_map.get(cls_idx, str(cls_idx))
                    elif isinstance(names_map, (list, tuple)) and 0 <= cls_idx < len(names_map):
                        cls_name = str(names_map[cls_idx])
                    else:
                        cls_name = str(cls_idx)

                    # draw OBB polygon and label on visualization image
                    poly_i32 = np.round(poly).astype(np.int32)
                    cv2.polylines(
                        img_draw,
                        [poly_i32],
                        isClosed=True,
                        color=(0, 255, 0),
                        thickness=2
                    )
                    text = f"{cls_name}:{conf_val:.2f}"
                    text_pos = (int(poly_i32[0][0]), int(poly_i32[0][1]))
                    cv2.putText(
                        img_draw,
                        text,
                        text_pos,
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.6,
                        (0, 0, 255),
                        2
                    )

                    # compute object's center as centroid of 4 points
                    centroid = np.mean(poly, axis=0)  # (x, y)
                    obj_x, obj_y = float(centroid[0]), float(centroid[1])

                    # convert to lon/lat
                    try:
                        lon, lat = pixel_to_geo(transform_info, obj_x, obj_y)
                        lon, lat = normalize_lon_lat(lon, lat)
                    except Exception as e:
                        print(f'[WARN] pixel->geo failed for {img_path.name} obj {i}: {e}')
                        continue

                    obj_counter += 1
                    obj_id = f'OBJ_{obj_counter:03d}'
                    subtype_map = optional_meta.get('subtype_map', {})
                    attributes_map = optional_meta.get('attributes_map', {})

                    detected_objects.append({
                        'object_id': obj_id,
                        'object_type': cls_name,
                        'subtype': subtype_map.get(cls_name),
                        'confidence': round(conf_val, 6),
                        'coordinates': {
                            'latitude': round(lat, 6),
                            'longitude': round(lon, 6),
                        },
                        'attributes': attributes_map.get(cls_name, {}),
                    })

            analysis_time = datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds')
            image_info = {
                'image_id': optional_meta.get('image_id', img_path.name),
                'image_url': optional_meta.get('image_url'),
                'capture_time': capture_time_iso,
                'sensor_type': optional_meta.get('sensor_type'),
                'scene_type': optional_meta.get('scene_type'),
            }

            record = {
                'request_id': request_id,
                'image_info': image_info,
                'analysis_metadata': {
                    'analysis_time': analysis_time,
                    'algorithm_version': optional_meta.get('algorithm_version'),
                    'coordinate_system': 'WGS84',
                    'processing_status': optional_meta.get('processing_status', 'success'),
                },
                'image_center': {
                    'latitude': round(img_center_lat, 6),
                    'longitude': round(img_center_lon, 6),
                },
                'detected_objects': detected_objects,
            }
            all_records.append(record)

            vis_path = out_json_path.parent / f'{img_path.stem}_obb.jpg'
            cv2.imwrite(str(vis_path), img_draw)
            print(f'[OK] wrote JSON record for {img_path.name}, detections: {len(detected_objects)}')
        except Exception as e:
            print(f'[ERROR] processing {img_path.name}: {e}')
            continue

    with open(out_json_path, 'w', encoding='utf-8') as f:
        json.dump(all_records, f, ensure_ascii=False, indent=2)

    print(f'All done. Output JSON: {out_json_path}')

# --------------------------
# CLI
# --------------------------
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--img-dir', required=True, help='folder containing images and per-image jsons')
    p.add_argument('--out-json', required=True, help='path to output json')
    p.add_argument('--model', required=True, help='path to ultralytics model weights (eg best.pt)')
    p.add_argument('--conf', default=0.5, type=float, help='confidence threshold')
    args = p.parse_args()

    process_folder(args.img_dir, args.out_json, args.model, conf=args.conf)